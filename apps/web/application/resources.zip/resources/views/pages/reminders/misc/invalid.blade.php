<!--no reminder-->
<div class="reminders-error" id="reminders-error">
    <div class="x-image">
        <img src="{{ url('/public/images/general-error.svg') }}" alt="404 - Not found" />
    </div>
    <div class="x-text">
        @lang('lang.action_not_completed_errors_found')
    </div>
</div>