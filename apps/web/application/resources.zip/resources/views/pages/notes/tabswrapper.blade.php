<!-- action buttons -->
@include('pages.notes.components.misc.list-page-actions')
<!-- action buttons -->

<!--notes table-->
<div class="card-embed-fix">
@include('pages.notes.components.table.wrapper')
</div>
<!--notes table-->