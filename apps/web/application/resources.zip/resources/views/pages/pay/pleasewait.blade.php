<div class="hidden payment-gateways" id="gateway-please-wait">
    <!--buttons-->
    <div class="x-button">
        <button class="btn btn-secondary button-loading-annimation" id="gateway-button-please-wait">
            {{ cleanLang(__('lang.please_wait')) }}</button>
    </div>
</div>