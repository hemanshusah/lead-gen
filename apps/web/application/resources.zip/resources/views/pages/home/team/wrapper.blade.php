<!--TOP STATS-->
<div id="js-trigger-home-team-wrapper">
@include('pages.home.team.widgets.first-row.wrapper')
@include('pages.home.team.widgets.second-row.wrapper')
</div>