<div class="row">
    <!--options panel-->
    @include('pages.canned.components.panel')


    <div class="col-sm-12 col-lg-9" id="canned-table-container">
        @include('pages.canned.components.table.table')
    </div>
</div>