<!--paragraph-->
<div class="form-paragraph">
    <div class="form-group row">
        <div class="col-12">
            {{ $payload['label'] }}
        </div>
    </div>
</div>