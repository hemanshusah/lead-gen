<!-- action buttons -->
@include('pages.tags.components.misc.list-page-actions')
<!-- action buttons -->

<!--tags table-->
<div class="card-embed-fix">
@include('pages.tags.components.table.wrapper')
</div>
<!--tags table-->