<!-- action buttons -->
@include('pages.fooos.components.misc.list-page-actions')


<!--fooos table-->
<div class="card-embed-fix">
@include('pages.fooos.components.table.wrapper')
</div>
