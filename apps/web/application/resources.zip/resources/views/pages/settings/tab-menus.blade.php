<!--custom fields - tab menu-->
@include('pages.settings.sections.customfields.tab-menu')

<!--other tab menus-->