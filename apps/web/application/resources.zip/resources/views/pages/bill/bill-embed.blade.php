<div class="embedded-bill clearfix">
    <!--INVOICE TABLE-->
@include('pages.bill.components.elements.main-table')

<!-- TOTAL & SUMMARY -->
@include('pages.bill.components.elements.totals-table')
</div>