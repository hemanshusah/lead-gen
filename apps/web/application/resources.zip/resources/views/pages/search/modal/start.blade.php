    <!--place holder-->
    <div class="search-modal-message" id="search-modal-message-start">
        <div class="x-holder-start">
            <img src="{{ url('public/images/search-icon.png') }}" alt="@lang('lang.search')" />

            <h5>@lang('lang.search_begin_message')</h5>

            <h6>@lang('lang.search_begin_submessage')</h6>
        </div>
    </div>