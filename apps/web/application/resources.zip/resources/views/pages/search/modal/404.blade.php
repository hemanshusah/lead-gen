<!--placeholder image-->
<div class="search-modal-message">
    <div class="x-holder-start">
        <img src="{{ url('public/images/search-404.png') }}" alt="@lang('lang.search')" />

        <h5>@lang('lang.search_no_results')</h5>

        <h6>@lang('lang.search_try_different')</h6>
    </div>
</div>