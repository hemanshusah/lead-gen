@extends('layout.wrapper') @section('content')
<!-- main content -->
<div class="container-fluid">

    <!--page heading-->
    <div class="row page-titles">

        <!-- Page Title & Bread Crumbs -->
        @include('misc.heading-crumbs')
        <!--Page Title & Bread Crumbs -->


        <!-- action buttons -->
        @include('pages.clients.components.misc.list-page-actions')
        <!-- action buttons -->

    </div>
    <!--page heading-->

    <!--stats panel-->
    <div class="stats-wrapper" id="clients-stats-wrapper">
        @include('misc.list-pages-stats')
    </div>
    <!--stats panel-->


    <!-- page content -->
    <div class="row">
        <div class="col-12">
            <!--clients table-->
            @include('pages.clients.components.table.wrapper')
            <!--clients table-->
        </div>
    </div>
    <!--page content -->


</div>
<!--main content -->
@endsection