<div class="row">
    <div class="col-lg-12 p-t-0 p-b-0">

        <div class="form-group row">
            <div class="col-6">
                @lang('lang.enter_new_time')
            </div>
        </div>
        <div class="form-group row">
            <div class="col-6">
                <input type="number" class="form-control  form-control-sm" id="time_hours"
                    name="time_hours" autocomplete="off" placeholder="Hours">
            </div>
            <div class="col-6">
                <input type="number" class="form-control  form-control-sm" id="time_minutes"
                    name="time_minutes" autocomplete="off" placeholder="Minutes">
            </div>
        </div>
    </div>
</div>