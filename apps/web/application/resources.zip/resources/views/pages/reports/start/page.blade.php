<div class="reports-start">

    <img src="{{ url('public/images/reports.svg') }}" alt="@lang('lang.error_404')" /> 

    <h5>@lang('lang.select_section_above_to_start')</h5>

</div>