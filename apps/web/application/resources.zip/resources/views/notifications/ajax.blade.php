<!-- use this for ajax rendered notifications -->
<div class="row">
    <div class="col-12">
        <div class="page-notification">
            <h2 class="font-weight-200">{{ $notification ?? '' }}</h2>
        </div>
    </div>
</div>